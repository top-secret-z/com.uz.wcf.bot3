ALTER TABLE wcf1_uzbot ADD postIsOfficial				TINYINT(1) DEFAULT 0;
ALTER TABLE wcf1_uzbot ADD threadIsOfficial				TINYINT(1) DEFAULT 0;