ALTER TABLE wcf1_uzbot ADD newsEntryData TEXT;
