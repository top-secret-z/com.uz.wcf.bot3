ALTER TABLE wcf1_uzbot_stats ADD blog INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogAccessEveryone INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogAccessRegistered INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogAccessFollowing INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogAccessOwner INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogFeatured INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogComments INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogLikes INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogSubscribers INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogViews INT(10) DEFAULT 0;

ALTER TABLE wcf1_uzbot_stats ADD blogEntry INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryAccessEveryone INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryAccessRegistered INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryAccessFollowing INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryAccessOwner INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryDeleted INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryDisabled INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryDraft INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryFeatured INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryPoll INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryPublished INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryComments INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryLikes INT(10) DEFAULT 0;
ALTER TABLE wcf1_uzbot_stats ADD blogEntryViews INT(10) DEFAULT 0;

ALTER TABLE wcf1_uzbot_stats ADD timeBlog INT(10) DEFAULT 0;
